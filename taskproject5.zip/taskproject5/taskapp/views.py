from django.shortcuts import render, redirect
from . models import TaskModel
from . forms import TaskModelForm, TaskUpdateForm

# Create your views here.
def index(request):
    data = TaskModel.objects.all().order_by('-date')
    form = TaskModelForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('/')
    total_tasks = data.count()
    completed = TaskModel.objects.filter(isComplete = True).count()
    uncomplete = total_tasks - completed
    context = {
        'data' : data,
        'form' : form,
        'tt' : total_tasks,
        'ct' : completed,
        'ut' : uncomplete
    }
    return render(request, 'taskapp/index.html', context)

def about(request):
    return render(request, 'taskapp/about.html')

def delete(request, pk):
    item = TaskModel.objects.get(id = pk)
    if request.method == "POST":
        item.delete()
        return redirect('/')
    return render(request, 'taskapp/delete.html')

def edit(request, pk):
    item = TaskModel.objects.get(id=pk)
    form = TaskUpdateForm(request.POST or None, instance=item)
    if form.is_valid():
        form.save()
        return redirect('/')
    context = {
        'form' : form,
    }
    return render(request, 'taskapp/edit.html', context)